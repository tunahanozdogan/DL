To generate the TFLite model, please follow this [notebook](https://github.com/tensorflow/codelabs/blob/main/KerasNLP/io2023_workshop.ipynb).
